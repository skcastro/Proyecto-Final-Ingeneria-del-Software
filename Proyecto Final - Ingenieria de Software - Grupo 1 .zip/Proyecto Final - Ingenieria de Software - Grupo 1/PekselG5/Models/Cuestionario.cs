﻿using System.ComponentModel.DataAnnotations.Schema;

namespace UsersApp.Models
{
    public class Cuestionario
    {
        public Guid id { get; set; }

        public Guid[] idPreguntas { get; set; }
        public Guid[] idUsuarios { get; set; }

        public string Titulo { get; set; }

        public string Preguntas { get; set; }
        public string Usuarios { get; set; }

        [NotMapped]
        public List<Pregunta> PreguntasArray { get; set; }

        [NotMapped]
        public List<Users> UsuariosArray { get; set; }

        [ForeignKey("idPregutas")]
        public virtual ICollection<Pregunta> PreguntasList { get; set; }
        [ForeignKey("idUsuarios")]
        public virtual ICollection<Users> UsuariosList { get; set; }
    }
}
