﻿using System.ComponentModel.DataAnnotations.Schema;

namespace UsersApp.Models
{
    public class Pregunta
    {
        public Guid id { get; set; }

        public string PreguntaTexto { get; set; }
        public string Respuesta1 { get; set; }
        public string Respuesta2 { get; set; }
        public string Respuesta3 { get; set; }
        public string Respuesta4 { get; set; }
        public string RespuestaCorrecta { get; set; }

        [NotMapped]
        public string RespuestaSeleccionada { get; set; }

        public virtual ICollection<Cuestionario> Cuestionarios { get; set; }
    }
}
