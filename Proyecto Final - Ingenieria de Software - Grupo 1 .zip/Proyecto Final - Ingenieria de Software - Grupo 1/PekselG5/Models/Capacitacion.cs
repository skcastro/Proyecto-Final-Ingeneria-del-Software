﻿using System.ComponentModel.DataAnnotations.Schema;
using UsersApp.Models;

namespace PekselG5.Models
{
    public class Capacitacion
    {
        public Guid id { get; set; }
        public Guid idCuestionario { get; set; }
        public string Estado { get; set; } = "Nuevo";
        public Guid[] idPreguntasFinalizadas { get; set; }

        [ForeignKey("idCuestionario")]
        public virtual Cuestionario Cuestionario { get; set; }

        [ForeignKey("idPreguntasFinalizadas")]
        public virtual ICollection<Pregunta> Preguntas { get; set; }
    }
}
