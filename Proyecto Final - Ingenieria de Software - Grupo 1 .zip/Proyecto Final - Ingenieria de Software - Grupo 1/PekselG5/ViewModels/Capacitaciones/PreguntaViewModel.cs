﻿using System.ComponentModel.DataAnnotations.Schema;

namespace PekselG5.ViewModels.Capacitaciones
{
    public class PreguntaViewModel
    {
        public Guid id { get; set; }
        public string PreguntaTexto { get; set; }
        public string Respuesta1 { get; set; }
        public string Respuesta2 { get; set; }
        public string Respuesta3 { get; set; }
        public string Respuesta4 { get; set; }
        public string RespuestaCorrecta { get; set; }
        public string RespuestaSeleccionada { get; set; }

        public Guid idCuestionario { get; set; }
        public Guid idCapacitacion { get; set; }
    }
}
