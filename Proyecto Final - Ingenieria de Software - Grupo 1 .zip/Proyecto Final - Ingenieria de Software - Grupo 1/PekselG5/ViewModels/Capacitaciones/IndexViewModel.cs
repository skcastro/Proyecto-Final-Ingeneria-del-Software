﻿namespace PekselG5.ViewModels.Capacitaciones
{
    public class IndexViewModel
    {
        public string Email { get; set; }
    }
}
