﻿using Microsoft.AspNetCore.Mvc.Rendering;
using UsersApp.Models;

namespace UsersApp.ViewModels.Cuestionarios
{
    public class CrearViewModel
    {
        public string Titulo { get; set; }

        public string Preguntas { get; set; }
        public string Usuarios { get; set; }

        public List<Pregunta> PreguntasArray { get; set; }

        public List<Users> UsuariosArray { get; set; }
    }
}
