﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PekselG5.Models;
using PekselG5.ViewModels.Capacitaciones;
using UsersApp.Data;
using UsersApp.Models;

namespace PekselG5.Controllers
{
    public class CapacitacionesController : Controller
    {
        private readonly AppDbContext _context;
        private readonly UserManager<Users> _userManager;
        public CapacitacionesController(AppDbContext context, UserManager<Users> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Index(IndexViewModel model)
        {
            var usr = await _userManager.FindByEmailAsync(model.Email);
            Cuestionario cuestionarioSeleccionado = new Cuestionario();

            if (usr != null)
            {
                var cuestionarios = await _context.Cuestionarios.ToListAsync();
                var capacitaciones = await _context.Capacitaciones.Where(c => c.Estado != "Finalizado").ToListAsync();

                foreach (var capacitaion in capacitaciones)
                {
                    var cuestionarioResuelto = await _context.Cuestionarios.FirstOrDefaultAsync(x => x.id == capacitaion.idCuestionario);
                    if (cuestionarioResuelto != null)
                    {
                        cuestionarios.Remove(cuestionarioResuelto);
                    }

                    if(capacitaion.Estado == "Incompleto")
                    {
                        RedirectToAction("Cuestionario", "Capacitaciones", new { id = capacitaion.idCuestionario });
                    }
                }

                if(cuestionarios.Count == 0)
                {
                    return RedirectToAction("NoCapacitaciones", "Capacitaciones");
                }



                foreach (var cuestionario in cuestionarios)
                {
                    if (cuestionario.idUsuarios.Length > 0)
                    {
                        foreach (var usrId in cuestionario.idUsuarios)
                        {
                            if (usrId.ToString() == usr.Id)
                            {
                                cuestionarioSeleccionado = cuestionario;
                            }
                        }
                    }
                }
            }

            await _context.Capacitaciones.AddAsync(new Capacitacion
            {
                idCuestionario = cuestionarioSeleccionado.id,
                Estado = "Empezado",
                Cuestionario = cuestionarioSeleccionado,
                idPreguntasFinalizadas = new Guid[0]
            });

            await _context.SaveChangesAsync();

            return RedirectToAction("Cuestionario", "Capacitaciones", new { id = cuestionarioSeleccionado.id });
        }

        [HttpGet]
        public async Task<IActionResult> Cuestionario(string id)
        {
            var cuestionario = await _context.Cuestionarios.FirstOrDefaultAsync(x => x.id == new Guid(id));

            if (cuestionario != null)
            {
                var capacitacion = await _context.Capacitaciones.FirstOrDefaultAsync(x => x.idCuestionario == new Guid(id));

                if (cuestionario.idPreguntas.Length > 0)
                {
                    cuestionario.PreguntasArray = new List<Pregunta>();
                    foreach (var pregunta in cuestionario.idPreguntas)
                    {
                        var prg = await _context.Preguntas.FirstOrDefaultAsync(x => x.id == pregunta);
                        if (prg != null)
                        {
                            cuestionario.PreguntasArray.Add(prg);
                        }
                    }
                }

                return View(capacitacion);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpGet]
        public async Task<IActionResult> Pregunta(Guid id, Guid idCuestionario, Guid idCapacitacion)
        {
            var pregunta = await _context.Preguntas.FirstOrDefaultAsync(x => x.id == id);
            if (pregunta == null)
            {
                return NotFound();
            }
            PreguntaViewModel viewModel = new PreguntaViewModel
            {
                id = id,
                PreguntaTexto = pregunta.PreguntaTexto,
                Respuesta1 = pregunta.Respuesta1,
                Respuesta2 = pregunta.Respuesta2,
                Respuesta3 = pregunta.Respuesta3,
                Respuesta4 = pregunta.Respuesta4,
                RespuestaCorrecta = pregunta.RespuestaCorrecta,
                idCapacitacion = idCapacitacion,
                idCuestionario = idCuestionario,
                RespuestaSeleccionada = String.Empty
            };
            return View(viewModel);
        }

        [HttpPost]
        public async Task<IActionResult> Pregunta(PreguntaViewModel _pregunta)
        {
            if (_pregunta.RespuestaSeleccionada == _pregunta.RespuestaCorrecta)
            {
                var pregunta = await _context.Preguntas.FirstOrDefaultAsync(x => x.id == _pregunta.id);
                var cuestionario = await _context.Cuestionarios.FirstOrDefaultAsync(x => x.id == _pregunta.idCuestionario);
                var capacitacion = await _context.Capacitaciones.FirstOrDefaultAsync(x => x.id == _pregunta.idCapacitacion);

                if (capacitacion != null)
                {
                    capacitacion.idPreguntasFinalizadas = capacitacion.idPreguntasFinalizadas.Append(_pregunta.id).ToArray();
                    _context.Update(capacitacion);
                    await _context.SaveChangesAsync();
                }

                if (cuestionario != null && capacitacion != null && pregunta != null)
                {
                    if (cuestionario.idPreguntas.Length == capacitacion.idPreguntasFinalizadas.Length)
                    {
                        capacitacion.Estado = "Finalizado";
                        _context.Update(capacitacion);
                        await _context.SaveChangesAsync();
                        return RedirectToAction("Finalizado", "Capacitaciones", new { id = capacitacion.id });
                    }
                    else
                    {
                        capacitacion.Estado = "Incompleto";

                        var siguientePreguntaId = cuestionario.idPreguntas.ToList().IndexOf(pregunta.id) + 1;

                        if (siguientePreguntaId < cuestionario.idPreguntas.Length)
                        {
                            var siguientePregunta = await _context.Preguntas.FirstOrDefaultAsync(x => x.id == cuestionario.idPreguntas[siguientePreguntaId]);
                            if (siguientePregunta != null)
                            {
                                _context.Update(capacitacion);
                                await _context.SaveChangesAsync();
                                return RedirectToAction("Pregunta", "Capacitaciones", new { id = siguientePregunta.id, idCuestionario = _pregunta.idCuestionario, idCapacitacion = capacitacion.id });
                            }
                            else
                            {
                                return NotFound();
                            }
                        }
                        else
                        {
                            return NotFound();
                        }
                    }
                }
                else
                {
                    return NotFound();
                }
            }
            else
            {
                return NotFound();
            }
        }

        [HttpGet]
        public async Task<IActionResult> Finalizado(Guid id)
        {
            List<Capacitacion> capacitacionesTerminadas = await _context.Capacitaciones.Where(c => c.Estado == "Finalizado").ToListAsync();

            foreach (var capacitacion in capacitacionesTerminadas)
            {
                var cuestionario = await _context.Cuestionarios.FirstOrDefaultAsync(x => x.id == capacitacion.idCuestionario);
                if (cuestionario != null)
                {
                    capacitacion.Cuestionario = cuestionario;
                    capacitacion.Cuestionario.PreguntasArray = new List<Pregunta>();
                    foreach (var preguntaId in cuestionario.idPreguntas)
                    {
                        var pregunta = await _context.Preguntas.FirstOrDefaultAsync(x => x.id == preguntaId);
                        if (pregunta != null)
                        {
                            capacitacion.Cuestionario.PreguntasArray.Add(pregunta);
                        }
                    }
                }
            }

            return View(capacitacionesTerminadas);
        }

        [HttpGet]
        public IActionResult NoCapacitaciones()
        {
            return View();
        }
    }
}
