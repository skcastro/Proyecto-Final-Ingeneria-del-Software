﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using UsersApp.Data;
using UsersApp.Models;
using UsersApp.ViewModels.Cuestionarios;

namespace UsersApp.Controllers
{
    public class CuestionariosController : Controller
    {
        private readonly AppDbContext _context;
        private readonly UserManager<Users> _userManager;

        public CuestionariosController(AppDbContext context, UserManager<Users> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> Crear()
        {
            List<Users> usuarios = await _userManager.Users.ToListAsync();
            List<Pregunta> preguntas = await _context.Preguntas.ToListAsync();
            ViewBag.Usuarios = new SelectList(usuarios, "Id", "UserName");
            ViewBag.Preguntas = new SelectList(preguntas, "id", "PreguntaTexto");
            var viewModel = new CrearViewModel
            {
                UsuariosArray = usuarios,
                PreguntasArray = preguntas
            };
            return View(viewModel);
        }

        [HttpPost]
        public async Task<IActionResult> Crear(CrearViewModel viewModel)
        {
            Request.Form.TryGetValue("Usuarios", out var usuarios);
            Request.Form.TryGetValue("Preguntas", out var preguntas);

            List<Users> auxUsrs = new List<Users>();
            List<Pregunta> auxPreguntas = new List<Pregunta>();

            foreach (var usuario in usuarios)
            {
                var usr = await _userManager.FindByIdAsync(usuario);

                if (usr != null)
                {
                    auxUsrs.Add(usr);
                }
            }

            foreach (var pregunta in preguntas)
            {
                var prg = await _context.Preguntas.FirstOrDefaultAsync(x => x.id == new Guid(pregunta));
                if (prg != null)
                {
                    auxPreguntas.Add(prg);
                }
            }

            await _context.Cuestionarios.AddAsync(new Cuestionario
            {
                Titulo = viewModel.Titulo,
                Preguntas = viewModel.Preguntas,
                Usuarios = viewModel.Usuarios,
                PreguntasList = auxPreguntas,
                UsuariosList = auxUsrs,
                PreguntasArray = auxPreguntas,
                UsuariosArray = auxUsrs,
                idPreguntas = auxPreguntas.Select(x => x.id).ToArray(),
                idUsuarios = auxUsrs.Select(x => new Guid(x.Id)).ToArray()
            });

            await _context.SaveChangesAsync();

            return RedirectToAction("Index", "Cuestionarios");
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var cuestionarios = await _context.Cuestionarios.ToArrayAsync();

            foreach (var cuestionario in cuestionarios)
            {

                cuestionario.UsuariosArray = new List<Users>();
                cuestionario.PreguntasArray = new List<Pregunta>();

                if (cuestionario.idUsuarios.Length > 0)
                {
                    foreach (var usr in cuestionario.idUsuarios)
                    {
                        var newUsr = await _userManager.FindByIdAsync(usr.ToString());

                        if (newUsr is not null)
                        {
                            cuestionario.UsuariosArray.Add(newUsr);
                        }
                    }
                }

                if (cuestionario.idPreguntas.Length > 0)
                {
                    foreach (var prg in cuestionario.idPreguntas)
                    {
                        var newPrg = await _context.Preguntas.FirstOrDefaultAsync(x => x.id == prg);

                        if (newPrg is not null)
                        {
                            cuestionario.PreguntasArray.Add(newPrg);
                        }
                    }
                }

            }

            return View(cuestionarios.ToList());
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> Editar(Guid id)
        {
            var cuestionario = await _context.Cuestionarios.FirstOrDefaultAsync(x => x.id == id);
            if (cuestionario == null)
            {
                return NotFound();
            }
            List<Users> usuarios = await _userManager.Users.ToListAsync();
            List<Pregunta> preguntas = await _context.Preguntas.ToListAsync();
            ViewBag.Usuarios = new SelectList(usuarios, "Id", "UserName",cuestionario.idUsuarios.Select(x => x.ToString()).ToArray());
            ViewBag.Preguntas = new SelectList(preguntas, "id", "PreguntaTexto", cuestionario.idPreguntas.Select(x => x.ToString()).ToArray());
            cuestionario.UsuariosArray = usuarios;
            cuestionario.PreguntasArray = preguntas;
            return View(cuestionario);
        }

        [HttpPost]
        public async Task<IActionResult> Editar(Cuestionario cuestionario)
        {
            var cuestionarioExistente = await _context.Cuestionarios.FirstOrDefaultAsync(x => x.id == cuestionario.id);
            if (cuestionarioExistente == null)
            {
                return NotFound();
            };

            Request.Form.TryGetValue("Usuarios", out var usuarios);
            Request.Form.TryGetValue("Preguntas", out var preguntas);

            List<Users> auxUsrs = new List<Users>();
            List<Pregunta> auxPreguntas = new List<Pregunta>();

            foreach (var usuario in usuarios)
            {
                var usr = await _userManager.FindByIdAsync(usuario);

                if (usr != null)
                {
                    auxUsrs.Add(usr);
                }
            }

            foreach (var pregunta in preguntas)
            {
                var prg = await _context.Preguntas.FirstOrDefaultAsync(x => x.id == new Guid(pregunta));
                if (prg != null)
                {
                    auxPreguntas.Add(prg);
                }
            }

            cuestionarioExistente.Titulo = cuestionario.Titulo;
            cuestionarioExistente.Preguntas = cuestionario.Preguntas;
            cuestionarioExistente.Usuarios = cuestionario.Usuarios;
            cuestionarioExistente.PreguntasList = auxPreguntas;
            cuestionarioExistente.UsuariosList = auxUsrs;
            cuestionarioExistente.PreguntasArray = auxPreguntas;
            cuestionarioExistente.UsuariosArray = auxUsrs;
            cuestionarioExistente.idPreguntas = auxPreguntas.Select(x => x.id).ToArray();
            cuestionarioExistente.idUsuarios = auxUsrs.Select(x => new Guid(x.Id)).ToArray();
            await _context.SaveChangesAsync();
            return RedirectToAction("Index", "Cuestionarios");
        }

        public async Task<IActionResult> Eliminar(Guid id)
        {
            var cuestionario = await _context.Cuestionarios
                .AsNoTracking()
                .FirstOrDefaultAsync(x => x.id == id);
            if (cuestionario == null)
            {
                return NotFound();
            }
            _context.Cuestionarios.Remove(cuestionario);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index", "Cuestionarios");
        }
    }
}
