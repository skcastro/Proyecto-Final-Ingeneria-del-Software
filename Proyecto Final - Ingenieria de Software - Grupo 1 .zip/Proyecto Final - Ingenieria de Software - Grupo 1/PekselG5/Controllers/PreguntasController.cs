﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UsersApp.Data;
using UsersApp.Models;
using UsersApp.ViewModels.Preguntas;

namespace UsersApp.Controllers
{
    public class PreguntasController : Controller
    {
        private readonly AppDbContext _context;

        public PreguntasController(AppDbContext context)
        {
            _context = context;
        }

        [Authorize]
        [HttpGet]
        public IActionResult Crear()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Crear(CrearViewModel viewModel)
        {
            await _context.Preguntas.AddAsync(new Pregunta
            {
                PreguntaTexto = viewModel.PreguntaTexto,
                Respuesta1 = viewModel.Respuesta1,
                Respuesta2 = viewModel.Respuesta2,
                Respuesta3 = viewModel.Respuesta3,
                Respuesta4 = viewModel.Respuesta4,
                RespuestaCorrecta = viewModel.RespuestaCorrecta
            });

            await _context.SaveChangesAsync();

            return RedirectToAction("Index", "Preguntas");
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var preguntas = await _context.Preguntas.ToArrayAsync();

            return View(preguntas.ToList());
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> Editar(Guid id)
        {
            var pregunta = await _context.Preguntas.FirstOrDefaultAsync(x => x.id == id);
            if (pregunta == null)
            {
                return NotFound();
            }
            
            return View(pregunta);
        }

        [HttpPost]
        public async Task<IActionResult> Editar(Pregunta pregunta)
        {
            var preguntaExistente = await _context.Preguntas.FirstOrDefaultAsync(x => x.id == pregunta.id);
            if (preguntaExistente == null)
            {
                return NotFound();
            }
            preguntaExistente.PreguntaTexto = pregunta.PreguntaTexto;
            preguntaExistente.Respuesta1 = pregunta.Respuesta1;
            preguntaExistente.Respuesta2 = pregunta.Respuesta2;
            preguntaExistente.Respuesta3 = pregunta.Respuesta3;
            preguntaExistente.Respuesta4 = pregunta.Respuesta4;
            preguntaExistente.RespuestaCorrecta = pregunta.RespuestaCorrecta;
            await _context.SaveChangesAsync();
            return RedirectToAction("Index", "Preguntas");
        }

        public async Task<IActionResult> Eliminar(Guid id)
        {
            var pregunta = await _context.Preguntas
                .AsNoTracking()
                .FirstOrDefaultAsync(x => x.id == id);
            if (pregunta == null)
            {
                return NotFound();
            }
            _context.Preguntas.Remove(pregunta);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index", "Preguntas");
        }
    }
}
