﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using PekselG5.Models;
using UsersApp.Models;

namespace UsersApp.Data
{
    public class AppDbContext : IdentityDbContext<Users>
    {
        public AppDbContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<Pregunta> Preguntas { get; set; }
        public DbSet<Cuestionario> Cuestionarios { get; set; }

        public DbSet<Capacitacion> Capacitaciones { get; set; }
    }
}
